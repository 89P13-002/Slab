/* The greeting program. This program demonstrates */
/* some of the components of a simple C program */
/* Written by: your name here */
/* Date: date program written */
#include <stdio.h>
int main (void)
{
/* Statements */
printf(“Hello World\n”);
return 0;
} /* main */
